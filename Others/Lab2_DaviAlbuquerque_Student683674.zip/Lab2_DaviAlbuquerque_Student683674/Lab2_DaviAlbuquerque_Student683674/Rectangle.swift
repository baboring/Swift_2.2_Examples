//
//  Rectangle.swift
//  Lab2_DaviAlbuquerque_Student683674
//
//  Created by macadmin on 2016-05-20.
//  Copyright © 2016 macadmin. All rights reserved.
//

import Foundation

//Class to define a Rectangle shape that is a subclass of the Shape class
public class Rectangle : Shape {
    var length: Int!
    var width: Int!
    
    //Designated initializer
    public init?(length: Int, width: Int){
        self.length = length
        self.width = width
        super.init()
        numberOfSides = 4
    }
    
    //Convenience initializer
    override public convenience init?(){
        self.init(length: 0 ,width: 0)
        numberOfSides = 0
    }
    
    //Description method to return the description of the class
    override public func description() -> String {
        return "Rectangle - \(numberOfSides) sides, length: \(self.length) and width: \(self.width)"
    }
}