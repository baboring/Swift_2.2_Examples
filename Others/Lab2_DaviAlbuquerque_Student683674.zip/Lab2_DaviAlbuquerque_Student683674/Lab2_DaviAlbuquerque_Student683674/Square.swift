//
//  Square.swift
//  Lab2_DaviAlbuquerque_Student683674
//
//  Created by macadmin on 2016-05-20.
//  Copyright © 2016 macadmin. All rights reserved.
//

import Foundation

//Class to define a Square shape that is a subclass of the Rectangle class
public class Square : Rectangle {
    
    //Designated initializer
    public init?(length: Int){
        super.init(length: length,width: length)
    }
    
    //Convenience initializer
    public convenience init?(){
        self.init(length: 0)
        numberOfSides = 0
    }
    
    //Description method to return the description of the class
    override public func description() -> String {
        return "Square - \(self.numberOfSides) sides, length: \(self.length)"
    }
}