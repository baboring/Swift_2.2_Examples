//
//  Shape.swift
//  Lab2_DaviAlbuquerque_Student683674
//
//  Created by macadmin on 2016-05-20.
//  Copyright © 2016 macadmin. All rights reserved.
//

import Foundation

//Create the class Shape to define a Shape
public class Shape {
    var numberOfSides :Int!
    
    //Designated initializer
    public init?(){
        numberOfSides = 0
    }
    
    //Method to return the description of the class
    public func description () -> String{
        return String(numberOfSides)
    }
}