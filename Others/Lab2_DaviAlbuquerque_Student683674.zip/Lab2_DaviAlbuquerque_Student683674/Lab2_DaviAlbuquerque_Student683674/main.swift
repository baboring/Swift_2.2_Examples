//
//  main.swift
//  Lab2_DaviAlbuquerque_Student683674
//
//  Created by macadmin on 2016-05-20.
//  Copyright © 2016 macadmin. All rights reserved.
//

import Foundation

//Main method that is going to be executed
func main(){

    let designatedSquare : Square = Square(length: 4)! //Instance of square using the designated initializer
    let convenienceSquare : Square = Square()! //Instance of square using the convenience initializer
    
    // Print the description of the class to verify that the code is working
    print(designatedSquare.description())
    print(convenienceSquare.description())
    
    let designatedRectangle : Rectangle = Rectangle(length: 4,width: 2)! //Instance of Rectangle using the designated initializer
    let convenienceRectangle : Rectangle = Rectangle()! //Instance of Rectangle using the convenience initializer

    // Print the description of the class to verify that the code is working
    print(designatedRectangle.description())
    print(convenienceRectangle.description())
    
}

main()